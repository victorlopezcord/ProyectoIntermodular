package GetToDay.controller;

import GetToDay.dto.RespuestaGeneral;
import GetToDay.repository.NegocioRepository;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/negocios")
public class NegociosController {

    @Autowired
    private NegocioRepository negocioRepository;

    @PostMapping("/listar")
    public ResponseEntity<RespuestaGeneral> listarNegocios() {
        try {
            List<Map<String, Object>> lista = negocioRepository.findAll().stream()
                .map(negocio -> {
                    Map<String, Object> datos = new HashMap<>();
                    datos.put("idNegocio", negocio.getIdNegocio());
                    datos.put("nombreLocal", negocio.getNombreLocal());
                    datos.put("direccion", negocio.getDireccion());
                    datos.put("descripcion", negocio.getDescripcion());
                    return datos;
                })
                .collect(Collectors.toList());
            return ResponseEntity.ok(new RespuestaGeneral(true, "Negocios obtenidos", lista));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }
}
