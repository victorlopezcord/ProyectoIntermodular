package GetToDay.dto;

public class PeticionServicio {
    private String email;
    private Integer idServicio;
    private Integer idNegocio;
    private String nombreServicio;
    private int precio;

    public PeticionServicio() {}

    public PeticionServicio(String email, Integer idServicio, String nombreServicio, int precio) {
        this.email = email;
        this.idServicio = idServicio;
        this.nombreServicio = nombreServicio;
        this.precio = precio;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Integer getIdServicio() { return idServicio; }
    public void setIdServicio(Integer idServicio) { this.idServicio = idServicio; }

    public Integer getIdNegocio() { return idNegocio; }
    public void setIdNegocio(Integer idNegocio) { this.idNegocio = idNegocio; }

    public String getNombreServicio() { return nombreServicio; }
    public void setNombreServicio(String nombreServicio) { this.nombreServicio = nombreServicio; }

    public int getPrecio() { return precio; }
    public void setPrecio(int precio) { this.precio = precio; }
}
