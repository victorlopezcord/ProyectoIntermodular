package GetToDay.controller;

import GetToDay.dto.PeticionCita;
import GetToDay.dto.RespuestaGeneral;
import GetToDay.entity.Citas;
import GetToDay.repository.CitasRepository;
import GetToDay.repository.NegocioRepository;
import GetToDay.repository.ServiciosRepository;
import GetToDay.repository.UsuarioRepository;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/citas")
public class CitasController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private NegocioRepository negocioRepository;

    @Autowired
    private ServiciosRepository serviciosRepository;

    @Autowired
    private CitasRepository citasRepository;

    @PostMapping("/crear")
    public ResponseEntity<RespuestaGeneral> crearCita(@RequestBody PeticionCita peticion) {
        try {
            return usuarioRepository.findByEmail(peticion.getEmailCliente())
                .map(cliente -> {
                    return serviciosRepository.findByIdServicio(peticion.getIdServicio())
                        .map(servicio -> {
                            Citas nueva = new Citas();
                            nueva.setFecha(Date.valueOf(peticion.getFecha()));
                            nueva.setHoraInicio(Time.valueOf(peticion.getHoraInicio()));
                            nueva.setEstado("pendiente");
                            nueva.setIdServicio(servicio);
                            nueva.setIdCliente(cliente);
                            Citas guardada = citasRepository.save(nueva);
                            return ResponseEntity.ok(new RespuestaGeneral(true, "Cita creada con éxito", construirDatosCita(guardada)));
                        })
                        .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(new RespuestaGeneral(false, "Servicio no encontrado")));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Cliente no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @PostMapping("/cliente")
    public ResponseEntity<RespuestaGeneral> citasCliente(@RequestBody PeticionCita peticion) {
        try {
            return usuarioRepository.findByEmail(peticion.getEmailCliente())
                .map(cliente -> {
                    List<Map<String, Object>> resultado = new ArrayList<>();
                    for (Citas cita : cliente.getCitasCollection()) {
                        resultado.add(construirDatosCita(cita));
                    }
                    return ResponseEntity.ok(new RespuestaGeneral(true, "Citas obtenidas", resultado));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Cliente no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @PostMapping("/negocio")
    public ResponseEntity<RespuestaGeneral> citasNegocio(@RequestBody PeticionCita peticion) {
        try {
            return usuarioRepository.findByEmail(peticion.getEmailDueno())
                .map(dueno -> {
                    return negocioRepository.findByIdUsuario(dueno)
                        .map(negocio -> {
                            List<Map<String, Object>> resultado = new ArrayList<>();
                            for (var servicio : negocio.getServiciosCollection()) {
                                for (Citas cita : servicio.getCitasCollection()) {
                                    resultado.add(construirDatosCita(cita));
                                }
                            }
                            return ResponseEntity.ok(new RespuestaGeneral(true, "Citas del negocio obtenidas", resultado));
                        })
                        .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(new RespuestaGeneral(false, "No se encontró el negocio del usuario")));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Usuario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @PutMapping("/modificar")
    public ResponseEntity<RespuestaGeneral> modificarCita(@RequestBody PeticionCita peticion) {
        try {
            return citasRepository.findById(peticion.getIdCita())
                .map(cita -> {
                    cita.setEstado(peticion.getEstado());
                    citasRepository.save(cita);
                    return ResponseEntity.ok(new RespuestaGeneral(true, "Estado de la cita actualizado", construirDatosCita(cita)));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Cita no encontrada")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    private Map<String, Object> construirDatosCita(Citas cita) {
        Map<String, Object> datos = new HashMap<>();

        datos.put("idCita", cita.getIdCita());
        datos.put("fecha", cita.getFecha());
        datos.put("horaInicio", cita.getHoraInicio());
        datos.put("estado", cita.getEstado());

        if (cita.getIdServicio() != null) {
            datos.put("idServicio", cita.getIdServicio().getIdServicio());
            datos.put("nombreServicio", cita.getIdServicio().getNombreServicio());
            datos.put("precio", cita.getIdServicio().getPrecio());

            if (cita.getIdServicio().getIdNegocio() != null) {
                datos.put("idNegocio", cita.getIdServicio().getIdNegocio().getIdNegocio());
                datos.put("nombreLocal", cita.getIdServicio().getIdNegocio().getNombreLocal());
                datos.put("direccion", cita.getIdServicio().getIdNegocio().getDireccion());
            }
        }

        if (cita.getIdCliente() != null) {
            datos.put("idCliente", cita.getIdCliente().getIdUsuario());
            datos.put("nombreCliente", cita.getIdCliente().getNombreCompleto());
            datos.put("emailCliente", cita.getIdCliente().getEmail());
            datos.put("telefonoCliente", cita.getIdCliente().getTelefono());
        }

        return datos;
    }
}
