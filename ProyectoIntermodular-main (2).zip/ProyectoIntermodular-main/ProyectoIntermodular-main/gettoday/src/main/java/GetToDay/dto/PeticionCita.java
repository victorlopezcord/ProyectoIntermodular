package GetToDay.dto;

public class PeticionCita {
    private String emailCliente;
    private String emailDueno;
    private Integer idServicio;
    private String fecha;
    private String horaInicio;
    private Integer idCita;
    private String estado;

    public PeticionCita() {}

    public String getEmailCliente() { return emailCliente; }
    public void setEmailCliente(String emailCliente) { this.emailCliente = emailCliente; }

    public String getEmailDueno() { return emailDueno; }
    public void setEmailDueno(String emailDueno) { this.emailDueno = emailDueno; }

    public Integer getIdServicio() { return idServicio; }
    public void setIdServicio(Integer idServicio) { this.idServicio = idServicio; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public String getHoraInicio() { return horaInicio; }
    public void setHoraInicio(String horaInicio) { this.horaInicio = horaInicio; }

    public Integer getIdCita() { return idCita; }
    public void setIdCita(Integer idCita) { this.idCita = idCita; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
