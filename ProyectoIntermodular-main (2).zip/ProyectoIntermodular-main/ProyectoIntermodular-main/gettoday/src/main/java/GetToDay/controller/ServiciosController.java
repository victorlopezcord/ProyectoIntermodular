package GetToDay.controller;

import GetToDay.dto.PeticionServicio;
import GetToDay.dto.RespuestaGeneral;
import GetToDay.entity.Servicios;
import GetToDay.repository.NegocioRepository;
import GetToDay.repository.ServiciosRepository;
import GetToDay.repository.UsuarioRepository;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/servicios")
public class ServiciosController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private NegocioRepository negocioRepository;

    @Autowired
    private ServiciosRepository serviciosRepository;

    @PostMapping("/crear")
    public ResponseEntity<RespuestaGeneral> crearServicio(@RequestBody PeticionServicio peticion) {
        try {
            return usuarioRepository.findByEmail(peticion.getEmail())
                .map(usuario -> {
                    return negocioRepository.findByIdUsuario(usuario)
                        .map(negocio -> {
                            Servicios nuevo = new Servicios();
                            nuevo.setNombreServicio(peticion.getNombreServicio());
                            nuevo.setPrecio(peticion.getPrecio());
                            nuevo.setIdNegocio(negocio);
                            Servicios guardado = serviciosRepository.save(nuevo);
                            return ResponseEntity.ok(new RespuestaGeneral(true, "Servicio creado con éxito", guardado.getIdServicio()));
                        })
                        .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(new RespuestaGeneral(false, "No se encontró el negocio del usuario")));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Usuario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @PostMapping("/listar")
    public ResponseEntity<RespuestaGeneral> listarServicios(@RequestBody PeticionServicio peticion) {
        try {
            return usuarioRepository.findByEmail(peticion.getEmail())
                .map(usuario -> {
                    return negocioRepository.findByIdUsuario(usuario)
                        .map(negocio -> {
                            var lista = new ArrayList<>(negocio.getServiciosCollection());
                            return ResponseEntity.ok(new RespuestaGeneral(true, "Servicios obtenidos", lista));
                        })
                        .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(new RespuestaGeneral(false, "No se encontró el negocio del usuario")));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Usuario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @PutMapping("/modificar")
    public ResponseEntity<RespuestaGeneral> modificarServicio(@RequestBody PeticionServicio peticion) {
        try {
            return serviciosRepository.findById(peticion.getIdServicio())
                .map(servicio -> {
                    servicio.setNombreServicio(peticion.getNombreServicio());
                    servicio.setPrecio(peticion.getPrecio());
                    serviciosRepository.save(servicio);
                    return ResponseEntity.ok(new RespuestaGeneral(true, "Servicio actualizado con éxito"));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Servicio no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @DeleteMapping("/eliminar")
    public ResponseEntity<RespuestaGeneral> eliminarServicio(@RequestBody PeticionServicio peticion) {
        try {
            return serviciosRepository.findById(peticion.getIdServicio())
                .map(servicio -> {
                    serviciosRepository.delete(servicio);
                    return ResponseEntity.ok(new RespuestaGeneral(true, "Servicio eliminado con éxito"));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Servicio no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }
}
