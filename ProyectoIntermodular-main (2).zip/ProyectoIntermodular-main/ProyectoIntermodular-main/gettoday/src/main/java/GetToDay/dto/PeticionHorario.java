package GetToDay.dto;

public class PeticionHorario {
    private String email;
    private Integer idHorario;
    private short diaSemana;
    private String horaApertura;
    private String horaCierre;

    public PeticionHorario() {}

    public PeticionHorario(String email, Integer idHorario, short diaSemana, String horaApertura, String horaCierre) {
        this.email = email;
        this.idHorario = idHorario;
        this.diaSemana = diaSemana;
        this.horaApertura = horaApertura;
        this.horaCierre = horaCierre;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Integer getIdHorario() { return idHorario; }
    public void setIdHorario(Integer idHorario) { this.idHorario = idHorario; }

    public short getDiaSemana() { return diaSemana; }
    public void setDiaSemana(short diaSemana) { this.diaSemana = diaSemana; }

    public String getHoraApertura() { return horaApertura; }
    public void setHoraApertura(String horaApertura) { this.horaApertura = horaApertura; }

    public String getHoraCierre() { return horaCierre; }
    public void setHoraCierre(String horaCierre) { this.horaCierre = horaCierre; }
}
