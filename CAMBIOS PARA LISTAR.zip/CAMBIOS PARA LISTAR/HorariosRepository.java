/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GetToDay.repository;

import GetToDay.entity.Horarios;
import GetToDay.entity.Negocios;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface HorariosRepository extends JpaRepository<Horarios, Integer> {
    Optional<Horarios> findByIdHorario(Integer idHorario);

    @Query("SELECT h FROM Horarios h WHERE h.idNegocio = :negocio")
    List<Horarios> findByIdNegocio(@Param("negocio") Negocios negocio);
}