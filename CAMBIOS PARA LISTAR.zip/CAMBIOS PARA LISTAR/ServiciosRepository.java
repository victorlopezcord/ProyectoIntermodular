/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GetToDay.repository;

import GetToDay.entity.Negocios;
import GetToDay.entity.Servicios;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiciosRepository extends JpaRepository<Servicios, Integer> {
    Optional<Servicios> findByIdServicio(Integer idServicio);

    @Query("SELECT s FROM Servicios s WHERE s.idNegocio = :negocio")
    List<Servicios> findByIdNegocio(@Param("negocio") Negocios negocio);
}