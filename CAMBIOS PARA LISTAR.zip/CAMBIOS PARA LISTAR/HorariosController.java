package GetToDay.controller;

import GetToDay.dto.PeticionHorario;
import GetToDay.dto.RespuestaGeneral;
import GetToDay.entity.Horarios;
import GetToDay.repository.HorariosRepository;
import GetToDay.repository.NegocioRepository;
import GetToDay.repository.UsuarioRepository;
import java.sql.Time;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/horarios")
public class HorariosController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private NegocioRepository negocioRepository;

    @Autowired
    private HorariosRepository horariosRepository;

    @PostMapping("/crear")
    public ResponseEntity<RespuestaGeneral> crearHorario(@RequestBody PeticionHorario peticion) {
        try {
            return usuarioRepository.findByEmail(peticion.getEmail())
                .map(usuario -> {
                    return negocioRepository.findByIdUsuario(usuario)
                        .map(negocio -> {
                            Horarios nuevo = new Horarios();
                            nuevo.setDiaSemana(peticion.getDiaSemana());
                            nuevo.setHoraApertura(Time.valueOf(peticion.getHoraApertura()));
                            nuevo.setHoraCierre(Time.valueOf(peticion.getHoraCierre()));
                            nuevo.setIdNegocio(negocio);
                            Horarios guardado = horariosRepository.save(nuevo);
                            return ResponseEntity.ok(new RespuestaGeneral(true, "Horario creado con éxito", guardado.getIdHorario()));
                        })
                        .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(new RespuestaGeneral(false, "No se encontró el negocio del usuario")));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Usuario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @PostMapping("/listar")
    public ResponseEntity<RespuestaGeneral> listarHorarios(@RequestBody PeticionHorario peticion) {
        try {
            return usuarioRepository.findByEmail(peticion.getEmail())
                .map(usuario -> {
                    return negocioRepository.findByIdUsuario(usuario)
                        .map(negocio -> {
                            var lista = horariosRepository.findByIdNegocio(negocio);
                            return ResponseEntity.ok(new RespuestaGeneral(true, "Horarios obtenidos", lista));
                        })
                        .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(new RespuestaGeneral(false, "No se encontró el negocio del usuario")));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Usuario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @PutMapping("/modificar")
    public ResponseEntity<RespuestaGeneral> modificarHorario(@RequestBody PeticionHorario peticion) {
        try {
            return horariosRepository.findById(peticion.getIdHorario())
                .map(horario -> {
                    horario.setDiaSemana(peticion.getDiaSemana());
                    horario.setHoraApertura(Time.valueOf(peticion.getHoraApertura()));
                    horario.setHoraCierre(Time.valueOf(peticion.getHoraCierre()));
                    horariosRepository.save(horario);
                    return ResponseEntity.ok(new RespuestaGeneral(true, "Horario actualizado con éxito"));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Horario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }

    @DeleteMapping("/eliminar")
    public ResponseEntity<RespuestaGeneral> eliminarHorario(@RequestBody PeticionHorario peticion) {
        try {
            return horariosRepository.findById(peticion.getIdHorario())
                .map(horario -> {
                    horariosRepository.delete(horario);
                    return ResponseEntity.ok(new RespuestaGeneral(true, "Horario eliminado con éxito"));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RespuestaGeneral(false, "Horario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(new RespuestaGeneral(false, "Error en el servidor: " + e.getMessage()));
        }
    }
}
